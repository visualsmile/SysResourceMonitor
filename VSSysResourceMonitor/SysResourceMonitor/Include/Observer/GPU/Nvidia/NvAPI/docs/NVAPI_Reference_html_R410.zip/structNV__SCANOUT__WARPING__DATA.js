var structNV__SCANOUT__WARPING__DATA =
[
    [ "numVertices", "structNV__SCANOUT__WARPING__DATA.html#ac7266927e0d57ce474ce92d30efecf33", null ],
    [ "textureRect", "structNV__SCANOUT__WARPING__DATA.html#ac6729e25450505822098093ef111aff7", null ],
    [ "version", "structNV__SCANOUT__WARPING__DATA.html#ae6758c4e932abe52a543a1e68777544e", null ],
    [ "vertexFormat", "structNV__SCANOUT__WARPING__DATA.html#a9b4cd151de3694a0dc90c22b6c1dc85c", null ],
    [ "vertices", "structNV__SCANOUT__WARPING__DATA.html#a22c1af01de1c0c1250161420420ba462", null ]
];