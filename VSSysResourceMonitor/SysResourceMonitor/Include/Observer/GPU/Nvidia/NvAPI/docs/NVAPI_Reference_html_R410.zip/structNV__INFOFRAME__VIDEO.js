var structNV__INFOFRAME__VIDEO =
[
    [ "activeFormatAspectRatio", "structNV__INFOFRAME__VIDEO.html#af9799fef549556169f2598d2e027bd9b", null ],
    [ "activeFormatInfoPresent", "structNV__INFOFRAME__VIDEO.html#a6b119b963cce396eec9c644212cda309", null ],
    [ "barInfo", "structNV__INFOFRAME__VIDEO.html#a2cd0720cdd72543edd092c6f96bb6b2c", null ],
    [ "bottom_bar", "structNV__INFOFRAME__VIDEO.html#aefd50887e2c0deaff7f88d5cbff1e415", null ],
    [ "colorimetry", "structNV__INFOFRAME__VIDEO.html#aa0b381174f44d6b7bd42a6a5aacbe2a1", null ],
    [ "colorSpace", "structNV__INFOFRAME__VIDEO.html#a60a9d48e87b99906e00b5e8168928f46", null ],
    [ "contentTypes", "structNV__INFOFRAME__VIDEO.html#a308e9d0ebf22f1758bbadd33a0477a9d", null ],
    [ "extendedColorimetry", "structNV__INFOFRAME__VIDEO.html#a20b13074f91bddae90012f09cb4b9968", null ],
    [ "Future17", "structNV__INFOFRAME__VIDEO.html#a9419bc6630a556c772448df775f4959b", null ],
    [ "Future47", "structNV__INFOFRAME__VIDEO.html#acb4c105d3698861fa8b115786a65a7be", null ],
    [ "itContent", "structNV__INFOFRAME__VIDEO.html#a266920bf54510061f0c6e3b76afc47e7", null ],
    [ "left_bar", "structNV__INFOFRAME__VIDEO.html#aaacff40ab74c91479d0c7410b9162e7d", null ],
    [ "nonuniformScaling", "structNV__INFOFRAME__VIDEO.html#ad6e8680fc2d9ec9ab4fc855e2d306318", null ],
    [ "picAspectRatio", "structNV__INFOFRAME__VIDEO.html#a688e85a92636790cb619dd9be80a5e43", null ],
    [ "pixelRepeat", "structNV__INFOFRAME__VIDEO.html#a5edb8b1482ead4376c3872cc5f28cc8c", null ],
    [ "rgbQuantizationRange", "structNV__INFOFRAME__VIDEO.html#aeb1569f1b4530644e32faddf2e7e58c9", null ],
    [ "right_bar", "structNV__INFOFRAME__VIDEO.html#a72f26e7d3bd5934f32cf14bacbdf1a78", null ],
    [ "scanInfo", "structNV__INFOFRAME__VIDEO.html#a8e9ba025a78e6e67e22bffa7a41f1866", null ],
    [ "top_bar", "structNV__INFOFRAME__VIDEO.html#a5fcf6600a6eb602252fdb3cc9e419bca", null ],
    [ "vic", "structNV__INFOFRAME__VIDEO.html#a5d95f4fc81bb913886c63a36d71fdf37", null ],
    [ "yccQuantizationRange", "structNV__INFOFRAME__VIDEO.html#aed84b94861919d6e8009bc3a11e26468", null ]
];