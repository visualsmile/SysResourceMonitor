var structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V2 =
[
    [ "bEnableSuperSamplingPredicationForVRS", "structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V2.html#a0ecdd707fd1658530f9064c59e7e5ee1", null ],
    [ "bEnableSuperSamplingPredicationForVRSAllAttributes", "structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V2.html#a7ea1ee46ff71b5be72cd5a8a728f1359", null ],
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V2.html#a7c251748a23e6d39d1e1d0fc37c1da24", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V2.html#a6b754ae81140cafcb86c9f0c1ba645e8", null ],
    [ "reserved", "structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V2.html#a8d16f7350361d737c9a0364442289cff", null ],
    [ "version", "structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V2.html#a1777960b558c9148a3cd52b0b90f80c8", null ]
];