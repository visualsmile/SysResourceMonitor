var structNV__I2C__INFO__V1 =
[
    [ "bIsDDCPort", "structNV__I2C__INFO__V1.html#afcd9e7a35f4f92e7970b619e8af52f07", null ],
    [ "cbSize", "structNV__I2C__INFO__V1.html#a39b4db8584a32d946f1a066cef3e9411", null ],
    [ "displayMask", "structNV__I2C__INFO__V1.html#a7a2533b67da3500dce5071ba498229f1", null ],
    [ "i2cDevAddress", "structNV__I2C__INFO__V1.html#a9e184dda03837e840c53eb11bd880fc5", null ],
    [ "i2cSpeed", "structNV__I2C__INFO__V1.html#a5de653ffb8f4de85a1659b9f637f4dbf", null ],
    [ "pbData", "structNV__I2C__INFO__V1.html#a1ea6df85c4ab15c9a3418ef20f18ac62", null ],
    [ "pbI2cRegAddress", "structNV__I2C__INFO__V1.html#ab26698b7d47195ce97407128bf2c4086", null ],
    [ "regAddrSize", "structNV__I2C__INFO__V1.html#aad9e6164f5efdfe5a99aa8a808426082", null ],
    [ "version", "structNV__I2C__INFO__V1.html#ac0135fea85485b77bd74edeba323a5c5", null ]
];