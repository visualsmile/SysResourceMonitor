var structNV__CHIPSET__INFO__v3 =
[
    [ "deviceId", "structNV__CHIPSET__INFO__v3.html#a20da191c965f0ea9e67a0dfc530f9df6", null ],
    [ "flags", "structNV__CHIPSET__INFO__v3.html#a7fbb01fb584bb8bb53dace460bcc8233", null ],
    [ "subSysDeviceId", "structNV__CHIPSET__INFO__v3.html#a57df921027063c89a9e143c70ce82d12", null ],
    [ "subSysVendorId", "structNV__CHIPSET__INFO__v3.html#ab12637a8f421adfef8981086a6726460", null ],
    [ "szChipsetName", "structNV__CHIPSET__INFO__v3.html#af0a95cf8b9e0ad347bae55cc4830cc40", null ],
    [ "szSubSysVendorName", "structNV__CHIPSET__INFO__v3.html#a7cbd90e34aacee8693729701769baa79", null ],
    [ "szVendorName", "structNV__CHIPSET__INFO__v3.html#a963da1bb0cd7ab1267eac637820a6b2c", null ],
    [ "vendorId", "structNV__CHIPSET__INFO__v3.html#a21d8897b3b1fd288f892f12be105fd8e", null ],
    [ "version", "structNV__CHIPSET__INFO__v3.html#ab4a8b6609491737bb1ec9859257dc791", null ]
];