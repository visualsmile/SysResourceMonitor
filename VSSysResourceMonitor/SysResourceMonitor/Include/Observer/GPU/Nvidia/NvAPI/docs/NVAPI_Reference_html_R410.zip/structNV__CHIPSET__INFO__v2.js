var structNV__CHIPSET__INFO__v2 =
[
    [ "deviceId", "structNV__CHIPSET__INFO__v2.html#a461914acc339e2985f6a9716941fa629", null ],
    [ "flags", "structNV__CHIPSET__INFO__v2.html#adffb658bec3a53ba2d2e867f9fee2b83", null ],
    [ "szChipsetName", "structNV__CHIPSET__INFO__v2.html#a4b404382f140735c49cdb853a52b7fbe", null ],
    [ "szVendorName", "structNV__CHIPSET__INFO__v2.html#a265fd8056453de0c773fd70c08df48ba", null ],
    [ "vendorId", "structNV__CHIPSET__INFO__v2.html#ae74702930dbec02d354ece925c276f45", null ],
    [ "version", "structNV__CHIPSET__INFO__v2.html#a98bd2aafac0e9f852d6fc0a619d64700", null ]
];