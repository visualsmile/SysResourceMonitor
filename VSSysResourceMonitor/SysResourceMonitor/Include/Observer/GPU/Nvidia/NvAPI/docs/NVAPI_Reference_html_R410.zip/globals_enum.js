var globals_enum =
[
    [ "_", "globals_enum.html", null ],
    [ "e", "globals_enum_e.html", null ],
    [ "n", "globals_enum_n.html", null ]
];