var structNVAPI__D3D12__PSO__HULL__SHADER__DESC__V2 =
[
    [ "UseSpecificShaderExt", "structNVAPI__D3D12__PSO__HULL__SHADER__DESC__V2.html#a7e1cc9d673b6822ea54c4f150d719f23", null ]
];