var structNV__MOSAIC__DISPLAY__TOPO__STATUS =
[
    [ "displayCount", "structNV__MOSAIC__DISPLAY__TOPO__STATUS.html#a7e18ac189d0d36722661a3f2f8e78988", null ],
    [ "displayId", "structNV__MOSAIC__DISPLAY__TOPO__STATUS.html#a60b22f46e3f95cf59fab7c64cfbc2129", null ],
    [ "displays", "structNV__MOSAIC__DISPLAY__TOPO__STATUS.html#a26b588d453cdc1aa45d262c2fcc06748", null ],
    [ "errorFlags", "structNV__MOSAIC__DISPLAY__TOPO__STATUS.html#a662be38bafb8552f309dbd8fd627411b", null ],
    [ "reserved", "structNV__MOSAIC__DISPLAY__TOPO__STATUS.html#a4454150876969dd3f810bef12735b85a", null ],
    [ "supportsRotation", "structNV__MOSAIC__DISPLAY__TOPO__STATUS.html#a6ea1043a47d9aa2b4fc4a30b6a31d50b", null ],
    [ "version", "structNV__MOSAIC__DISPLAY__TOPO__STATUS.html#a06100fe1e6464188a02fe990810980e9", null ],
    [ "warningFlags", "structNV__MOSAIC__DISPLAY__TOPO__STATUS.html#a87475f089a7b12447b2109fbe2547b95", null ]
];