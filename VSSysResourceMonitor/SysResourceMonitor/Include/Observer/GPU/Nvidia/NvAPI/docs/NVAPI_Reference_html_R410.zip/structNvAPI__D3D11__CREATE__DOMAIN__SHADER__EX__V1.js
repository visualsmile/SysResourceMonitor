var structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V1 =
[
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V1.html#ac3f89dcb73e51dd5b2107323a0264c01", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V1.html#a538976adb111ac837c3946833aa37008", null ],
    [ "version", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V1.html#a8437a71bcc68ac464ce5e05e8fa966e1", null ]
];