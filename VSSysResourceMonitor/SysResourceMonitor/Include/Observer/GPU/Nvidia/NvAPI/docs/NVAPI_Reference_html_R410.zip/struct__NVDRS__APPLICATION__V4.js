var struct__NVDRS__APPLICATION__V4 =
[
    [ "appName", "struct__NVDRS__APPLICATION__V4.html#ab730e5611cccfa554306d69a258516f4", null ],
    [ "commandLine", "struct__NVDRS__APPLICATION__V4.html#a8a14e8b42ef28b6ede38921286107cc0", null ],
    [ "fileInFolder", "struct__NVDRS__APPLICATION__V4.html#a42b93e35e0aa3b33265f3342a4f55077", null ],
    [ "isCommandLine", "struct__NVDRS__APPLICATION__V4.html#a47cb3694daaa19d3b76436caa2591d04", null ],
    [ "isMetro", "struct__NVDRS__APPLICATION__V4.html#add8e7ea1e9a7359d5a9dbe92dcb328a2", null ],
    [ "isPredefined", "struct__NVDRS__APPLICATION__V4.html#ac1f13277b433a0bbf40c5aa1e55e52be", null ],
    [ "launcher", "struct__NVDRS__APPLICATION__V4.html#a0fbe59b9240c38f46700e7797c5240a1", null ],
    [ "reserved", "struct__NVDRS__APPLICATION__V4.html#a58716c5e752a65ad6eccac0b3511024b", null ],
    [ "userFriendlyName", "struct__NVDRS__APPLICATION__V4.html#a0b05a3c4682445fbb0a6db55ff1866b0", null ],
    [ "version", "struct__NVDRS__APPLICATION__V4.html#a6d27c68e9bfeb959df6956d7e00c05cc", null ]
];