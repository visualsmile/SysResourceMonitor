var struct__NVDRS__BINARY__SETTING =
[
    [ "valueData", "struct__NVDRS__BINARY__SETTING.html#a18e740fd87d103c30b0aab1c3f0df1df", null ],
    [ "valueLength", "struct__NVDRS__BINARY__SETTING.html#ad1592d243a85f0cd93839b3ddf3a3329", null ]
];