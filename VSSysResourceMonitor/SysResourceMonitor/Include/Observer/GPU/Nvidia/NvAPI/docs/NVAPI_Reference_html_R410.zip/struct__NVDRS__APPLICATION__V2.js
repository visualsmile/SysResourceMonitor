var struct__NVDRS__APPLICATION__V2 =
[
    [ "appName", "struct__NVDRS__APPLICATION__V2.html#aa0b91456f4b4932e1bba335df7569a51", null ],
    [ "fileInFolder", "struct__NVDRS__APPLICATION__V2.html#a2279c5937352df77e45b0605180c5c68", null ],
    [ "isPredefined", "struct__NVDRS__APPLICATION__V2.html#a68a0053786635e1d8ea657f6ce551f1c", null ],
    [ "launcher", "struct__NVDRS__APPLICATION__V2.html#abf30b169a43a9e6fbe6ddad26d04841d", null ],
    [ "userFriendlyName", "struct__NVDRS__APPLICATION__V2.html#a3cfdea8f4eaad0f96b088e2c1101da09", null ],
    [ "version", "struct__NVDRS__APPLICATION__V2.html#a978fe4ed76120555e593e3d6b8e5ecaa", null ]
];