var group__dispapi =
[
    [ "Display Handle Interface", "group__disphandle.html", "group__disphandle" ],
    [ "Display Control Interface", "group__dispcontrol.html", "group__dispcontrol" ]
];