var structNV__MULTIGPU__CAPS =
[
    [ "multiGPUVersion", "structNV__MULTIGPU__CAPS.html#ab080f1afa1b41927d3b754a1cfbecb45", null ],
    [ "nSLIGPUs", "structNV__MULTIGPU__CAPS.html#aa19225d5fd3721c2b9882dfaf9937736", null ],
    [ "nTotalGPUs", "structNV__MULTIGPU__CAPS.html#af49368203ad2f4d1fdc4512827105862", null ],
    [ "reserved", "structNV__MULTIGPU__CAPS.html#a93c09fd462c36916d1e6652e908d5b9a", null ],
    [ "videoBridgePresent", "structNV__MULTIGPU__CAPS.html#a353012d14a00597688663839dd221d6a", null ]
];