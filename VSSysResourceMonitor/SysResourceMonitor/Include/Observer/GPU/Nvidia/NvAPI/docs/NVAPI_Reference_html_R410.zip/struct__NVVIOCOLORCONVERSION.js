var struct__NVVIOCOLORCONVERSION =
[
    [ "colorMatrix", "struct__NVVIOCOLORCONVERSION.html#a8da38b580d48ef4c6c08fb529a781aa0", null ],
    [ "colorOffset", "struct__NVVIOCOLORCONVERSION.html#aa1fa9b2a71d5e3ef6a254d63e8a065f5", null ],
    [ "colorScale", "struct__NVVIOCOLORCONVERSION.html#aed10a14b44689ef99874042234e557f3", null ],
    [ "compositeSafe", "struct__NVVIOCOLORCONVERSION.html#aaf07d17968f8e58a106b7e8ee1515447", null ],
    [ "version", "struct__NVVIOCOLORCONVERSION.html#a6ee2ff941e4b8bf9d64007b801b9a8b4", null ]
];