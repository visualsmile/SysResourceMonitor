var structNV__VIEW__TARGET__INFO =
[
    [ "bForceModeSet", "structNV__VIEW__TARGET__INFO.html#a0c08ec5ed2dec44595b55c932c56ea6e", null ],
    [ "bGDIPrimary", "structNV__VIEW__TARGET__INFO.html#a8d510c00f0c80ba21ac70a347064aa60", null ],
    [ "bInterlaced", "structNV__VIEW__TARGET__INFO.html#a53ebb2efa4f29e5a66743defcd562dba", null ],
    [ "bPrimary", "structNV__VIEW__TARGET__INFO.html#a165579fb0eecd2dfae42bda6794d6ead", null ],
    [ "count", "structNV__VIEW__TARGET__INFO.html#a481c00a24f59c64c9647d102a8560ad6", null ],
    [ "deviceMask", "structNV__VIEW__TARGET__INFO.html#a7286dc54e165f8f067651bc0c1acf249", null ],
    [ "sourceId", "structNV__VIEW__TARGET__INFO.html#acc287d53699ad927e3b52a05dcdec59a", null ],
    [ "target", "structNV__VIEW__TARGET__INFO.html#afab999ce6069d4bc7452dd6291e87606", null ],
    [ "version", "structNV__VIEW__TARGET__INFO.html#a9d6f2b8776ceb6d8eac058607ecd4c73", null ]
];