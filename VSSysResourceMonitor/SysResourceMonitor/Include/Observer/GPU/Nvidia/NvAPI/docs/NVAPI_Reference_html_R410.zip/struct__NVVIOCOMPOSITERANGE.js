var struct__NVVIOCOMPOSITERANGE =
[
    [ "uEnabled", "struct__NVVIOCOMPOSITERANGE.html#ae2abb30655944c17d5876e558bbed230", null ],
    [ "uMax", "struct__NVVIOCOMPOSITERANGE.html#ae73162ad5958f703d17abf2255d27ece", null ],
    [ "uMin", "struct__NVVIOCOMPOSITERANGE.html#a2875ed6dafbf57f4cc34d90598fee918", null ],
    [ "uRange", "struct__NVVIOCOMPOSITERANGE.html#a26a303d882cdc0110388f759e4173f0d", null ]
];