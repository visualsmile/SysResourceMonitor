var structNV__GET__CURRENT__SLI__STATE__V2 =
[
    [ "bIsCurAFRGroupNew", "structNV__GET__CURRENT__SLI__STATE__V2.html#a67e0b6f4cd73b070b61a941a4f0c75b0", null ],
    [ "currentAFRIndex", "structNV__GET__CURRENT__SLI__STATE__V2.html#a3bec1bf09aaf2a44e19e5398535c2c11", null ],
    [ "maxNumAFRGroups", "structNV__GET__CURRENT__SLI__STATE__V2.html#a26a30a2c3f2455761ed601c016c433ef", null ],
    [ "nextFrameAFRIndex", "structNV__GET__CURRENT__SLI__STATE__V2.html#a74d92c5dad9231769d238eb702a1a12f", null ],
    [ "numAFRGroups", "structNV__GET__CURRENT__SLI__STATE__V2.html#af3b86d7a36a16ec1c6aa645716f29f5c", null ],
    [ "numVRSLIGpus", "structNV__GET__CURRENT__SLI__STATE__V2.html#a8c9efaf4922d87ca948242e9863a16db", null ],
    [ "previousFrameAFRIndex", "structNV__GET__CURRENT__SLI__STATE__V2.html#ac9666a9669db3cc600dbe1c31f89d47b", null ],
    [ "version", "structNV__GET__CURRENT__SLI__STATE__V2.html#acf73f39cc67e4b8591301f944ca58a85", null ]
];