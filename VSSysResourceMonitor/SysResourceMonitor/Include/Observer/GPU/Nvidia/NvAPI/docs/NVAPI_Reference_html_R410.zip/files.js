var files =
[
    [ "nvapi.h", "nvapi_8h.html", "nvapi_8h" ],
    [ "nvapi_lite_common.h", "nvapi__lite__common_8h.html", "nvapi__lite__common_8h" ],
    [ "nvapi_lite_d3dext.h", "nvapi__lite__d3dext_8h.html", "nvapi__lite__d3dext_8h" ],
    [ "nvapi_lite_salend.h", "nvapi__lite__salend_8h.html", null ],
    [ "nvapi_lite_salstart.h", "nvapi__lite__salstart_8h.html", "nvapi__lite__salstart_8h" ],
    [ "nvapi_lite_sli.h", "nvapi__lite__sli_8h.html", "nvapi__lite__sli_8h" ],
    [ "nvapi_lite_stereo.h", "nvapi__lite__stereo_8h.html", "nvapi__lite__stereo_8h" ],
    [ "nvapi_lite_surround.h", "nvapi__lite__surround_8h.html", "nvapi__lite__surround_8h" ],
    [ "NvApiDriverSettings.h", "NvApiDriverSettings_8h.html", "NvApiDriverSettings_8h" ],
    [ "nvHLSLExtns.h", "nvHLSLExtns_8h.html", "nvHLSLExtns_8h" ],
    [ "nvHLSLExtnsInternal.h", "nvHLSLExtnsInternal_8h.html", "nvHLSLExtnsInternal_8h" ],
    [ "nvShaderExtnEnums.h", "nvShaderExtnEnums_8h.html", "nvShaderExtnEnums_8h" ]
];