var structNV__GPU__ECC__CONFIGURATION__INFO =
[
    [ "isEnabled", "structNV__GPU__ECC__CONFIGURATION__INFO.html#a6311aeaaff6181dc2477b4001dde2c32", null ],
    [ "isEnabledByDefault", "structNV__GPU__ECC__CONFIGURATION__INFO.html#a76d67114e1dfddb85d2dc10cce4f9a70", null ],
    [ "version", "structNV__GPU__ECC__CONFIGURATION__INFO.html#a832bb9b368077603bffa0afbc0feb7df", null ]
];