var structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5 =
[
    [ "ConvertToFastGS", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#addd12153988150bbc7c8da9337dc7408", null ],
    [ "DontUseViewportOrder", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#a3738ff2fddedf0c302c3d4d5afa1caca", null ],
    [ "ForceFastGS", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#a5b93a019d48788462e7e19159d081f99", null ],
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#a36b56bc47ade33a3f667252472c56cec", null ],
    [ "OffsetRtIndexByVpIndex", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#abe8cbd19639c2d5a66aaebecfc5523c3", null ],
    [ "pCoordinateSwizzling", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#a9241e657811a84413dad07712a20e32e", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#ab98e639a3309d732d7f9002595e0e8ce", null ],
    [ "UseAttributeSkipMask", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#ab1018ce7f989b61794c5a623af516a43", null ],
    [ "UseCoordinateSwizzle", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#a5979937f48a407356fd87853bbc4fce3", null ],
    [ "UseSpecificShaderExt", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#a33d84a1832b3d49f67c138607e3fc14f", null ],
    [ "UseViewportMask", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#a195f2029b0687ece1d884a2e19430e11", null ],
    [ "version", "structNvAPI__D3D11__CREATE__GEOMETRY__SHADER__EX__V5.html#a73686d58af47357187ea3b7871373111", null ]
];