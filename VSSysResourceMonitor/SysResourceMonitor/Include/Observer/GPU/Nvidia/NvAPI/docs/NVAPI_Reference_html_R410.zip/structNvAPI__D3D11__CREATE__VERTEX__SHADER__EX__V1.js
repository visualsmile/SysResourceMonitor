var structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V1 =
[
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V1.html#a56c0debc46da62a5559362de40f427ca", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V1.html#a0b3fd29a850ae04bfeb2cac7d8292cb3", null ],
    [ "version", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V1.html#aef9d7b65c3afef3862b3e06b9342ea07", null ]
];