var structNV__GPU__PERF__PSTATES__INFO__V1 =
[
    [ "clocks", "structNV__GPU__PERF__PSTATES__INFO__V1.html#a3df6a50b2022469dc2a246c9574dc1d0", null ],
    [ "domainId", "structNV__GPU__PERF__PSTATES__INFO__V1.html#ace9392536f70dc31c41734ec18249197", null ],
    [ "flags", "structNV__GPU__PERF__PSTATES__INFO__V1.html#aaa5f3cdc79a075b4288b9c5273179457", null ],
    [ "freq", "structNV__GPU__PERF__PSTATES__INFO__V1.html#a11db280e622ac0fc4f7fd5da0a49baa2", null ],
    [ "numClocks", "structNV__GPU__PERF__PSTATES__INFO__V1.html#a54d201d22dcbc293e327f5890984d8a5", null ],
    [ "numPstates", "structNV__GPU__PERF__PSTATES__INFO__V1.html#ae78cf1b1b750f6801224185faebeeeb3", null ],
    [ "pstateId", "structNV__GPU__PERF__PSTATES__INFO__V1.html#a0c32dfb576aeb34728e56643ea718088", null ],
    [ "pstates", "structNV__GPU__PERF__PSTATES__INFO__V1.html#ad83cbfcbf73de76c70451cd743140420", null ],
    [ "version", "structNV__GPU__PERF__PSTATES__INFO__V1.html#a10ba3ab2bd3675435c961fe1a77fd474", null ]
];