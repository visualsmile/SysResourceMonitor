var structNV__CHIPSET__INFO__v4 =
[
    [ "deviceId", "structNV__CHIPSET__INFO__v4.html#acf89436a536491f65a9155c2c40a7344", null ],
    [ "flags", "structNV__CHIPSET__INFO__v4.html#a460cdfa19ec89f65e7c615e68d29cdca", null ],
    [ "HBdeviceId", "structNV__CHIPSET__INFO__v4.html#a0be64201163de3c26d1a46ea652f0ef0", null ],
    [ "HBsubSysDeviceId", "structNV__CHIPSET__INFO__v4.html#ac5b68eafd88c8668f97cc1420fc56bff", null ],
    [ "HBsubSysVendorId", "structNV__CHIPSET__INFO__v4.html#afacb32fa84ea0e581d5978312a9d6417", null ],
    [ "HBvendorId", "structNV__CHIPSET__INFO__v4.html#a4ad6dd7800b9c59c0a0c5e68444a818c", null ],
    [ "subSysDeviceId", "structNV__CHIPSET__INFO__v4.html#add3d65692c20a134d082f189a8c0f7c5", null ],
    [ "subSysVendorId", "structNV__CHIPSET__INFO__v4.html#a8a9317a5d1919eaa49e9758cebf533cb", null ],
    [ "szChipsetName", "structNV__CHIPSET__INFO__v4.html#aa19e0d02b34cceced84f7353e0839f6d", null ],
    [ "szSubSysVendorName", "structNV__CHIPSET__INFO__v4.html#a618c3d0647bf02cb71bc52822462a695", null ],
    [ "szVendorName", "structNV__CHIPSET__INFO__v4.html#a73ee00ae247700d4807b12318c417098", null ],
    [ "vendorId", "structNV__CHIPSET__INFO__v4.html#acc49eb0a943c6d348a9f36d8c3b35c9d", null ],
    [ "version", "structNV__CHIPSET__INFO__v4.html#a5a17237ae606a3793ec8dde7c6188bb5", null ]
];