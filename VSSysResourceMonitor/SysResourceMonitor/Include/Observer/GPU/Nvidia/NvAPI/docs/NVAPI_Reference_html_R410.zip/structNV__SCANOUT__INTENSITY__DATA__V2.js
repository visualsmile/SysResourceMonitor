var structNV__SCANOUT__INTENSITY__DATA__V2 =
[
    [ "blendingTexture", "structNV__SCANOUT__INTENSITY__DATA__V2.html#a69ba61a24160fe570d9636dc334be375", null ],
    [ "height", "structNV__SCANOUT__INTENSITY__DATA__V2.html#aeffdc47518bfa790976d7b6b26e45879", null ],
    [ "offsetTexChannels", "structNV__SCANOUT__INTENSITY__DATA__V2.html#ab13b5a5f2e047dec0b760347411e5c27", null ],
    [ "offsetTexture", "structNV__SCANOUT__INTENSITY__DATA__V2.html#aa6c1611789b136d1d969bac3e785db56", null ],
    [ "version", "structNV__SCANOUT__INTENSITY__DATA__V2.html#a8e94da8f80d4358eafbb1e1a3260c87a", null ],
    [ "width", "structNV__SCANOUT__INTENSITY__DATA__V2.html#a277dabfbe3d4ec80984fd0f83634b332", null ]
];