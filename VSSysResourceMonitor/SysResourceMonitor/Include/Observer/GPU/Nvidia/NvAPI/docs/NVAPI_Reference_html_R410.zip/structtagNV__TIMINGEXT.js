var structtagNV__TIMINGEXT =
[
    [ "aspect", "structtagNV__TIMINGEXT.html#ae809263134899b834a59e362ae7e69e2", null ],
    [ "flag", "structtagNV__TIMINGEXT.html#ab69bf56a0a597ceaeba4f8cf2c7347f0", null ],
    [ "name", "structtagNV__TIMINGEXT.html#a4493bfae0cb347fcdb117fc7c0afc3da", null ],
    [ "rep", "structtagNV__TIMINGEXT.html#a19d1bc53351bf8fcf809fc6dc3d44d44", null ],
    [ "rr", "structtagNV__TIMINGEXT.html#ae80dff16c129fa4ca74a66bd95570a18", null ],
    [ "rrx1k", "structtagNV__TIMINGEXT.html#abec402c9566c84d7bfe64617ff61558c", null ],
    [ "status", "structtagNV__TIMINGEXT.html#a9b83d1bbbb631e3456313a01406dd932", null ]
];