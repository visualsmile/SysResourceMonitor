var nvShaderExtnEnums_8h =
[
    [ "NV_EXTN_OP_FP16_ATOMIC", "nvShaderExtnEnums_8h.html#ad27af7a9543371c90d09e5cf61daa106", null ],
    [ "NV_EXTN_OP_FP32_ATOMIC", "nvShaderExtnEnums_8h.html#a76f6fc54ced6ffe1a47fd89062123f70", null ],
    [ "NV_EXTN_OP_GET_LANE_ID", "nvShaderExtnEnums_8h.html#aa36a23a1edbd0b366444a448b266b1cb", null ],
    [ "NV_EXTN_OP_GET_SHADING_RATE", "nvShaderExtnEnums_8h.html#a39294ffabd18d66dd5e6013c0a7577b2", null ],
    [ "NV_EXTN_OP_SHFL", "nvShaderExtnEnums_8h.html#a434ca79cc2215bf2e5a9b0856b40ef6d", null ],
    [ "NV_EXTN_OP_SHFL_DOWN", "nvShaderExtnEnums_8h.html#a127cac5170dc8a6ef0aafc2576c4cb2a", null ],
    [ "NV_EXTN_OP_SHFL_UP", "nvShaderExtnEnums_8h.html#a5ca67247b0034b74a21a2a20f492c20f", null ],
    [ "NV_EXTN_OP_SHFL_XOR", "nvShaderExtnEnums_8h.html#a074efc08ca74d5be9bed8096502985b8", null ],
    [ "NV_EXTN_OP_UINT64_ATOMIC", "nvShaderExtnEnums_8h.html#a9ff9cc9e5eb3da964f21452246202965", null ],
    [ "NV_EXTN_OP_VOTE_ALL", "nvShaderExtnEnums_8h.html#ace6fb69545d9974e3c7607e4f839e5af", null ],
    [ "NV_EXTN_OP_VOTE_ANY", "nvShaderExtnEnums_8h.html#aff18dc0128bf1ed4e83cb618faed585a", null ],
    [ "NV_EXTN_OP_VOTE_BALLOT", "nvShaderExtnEnums_8h.html#a8f7ea9496692682fa17c6767d1b95d9b", null ],
    [ "NV_EXTN_OP_VPRS_EVAL_ATTRIB_AT_SAMPLE", "nvShaderExtnEnums_8h.html#acc7de966cd9e7a87587171d5f2f626c8", null ],
    [ "NV_SHADER_EXTN_VERSION", "nvShaderExtnEnums_8h.html#aaa6ab412ff7a3528d0808a5027153f9b", null ],
    [ "NV_WARP_SIZE", "nvShaderExtnEnums_8h.html#a359f0c9c1aef4d54d6b79b3a95201cef", null ]
];