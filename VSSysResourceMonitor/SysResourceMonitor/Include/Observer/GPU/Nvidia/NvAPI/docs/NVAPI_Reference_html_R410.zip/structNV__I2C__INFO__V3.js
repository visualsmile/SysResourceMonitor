var structNV__I2C__INFO__V3 =
[
    [ "bIsDDCPort", "structNV__I2C__INFO__V3.html#accb97600ad001ee3b51de43cbc004012", null ],
    [ "bIsPortIdSet", "structNV__I2C__INFO__V3.html#ab016e331bd81387a4ca2e4d0e536a373", null ],
    [ "cbSize", "structNV__I2C__INFO__V3.html#a04e3eff10299a154ca7b07e41a6938ab", null ],
    [ "displayMask", "structNV__I2C__INFO__V3.html#a4e126a23c16549bda22d87314a2a3a7b", null ],
    [ "i2cDevAddress", "structNV__I2C__INFO__V3.html#a5972bc8bdb1eb6ff60cdb2cfa36a8d59", null ],
    [ "i2cSpeed", "structNV__I2C__INFO__V3.html#ade08a919e3a998a57c474cc34f894ce7", null ],
    [ "i2cSpeedKhz", "structNV__I2C__INFO__V3.html#a52c8d99d11e63a045337b8792980aa2c", null ],
    [ "pbData", "structNV__I2C__INFO__V3.html#aa0403f0175fc71b0b3d18cb9d4a2f157", null ],
    [ "pbI2cRegAddress", "structNV__I2C__INFO__V3.html#a9c80bc9db0f952d5ac891e776955ca69", null ],
    [ "portId", "structNV__I2C__INFO__V3.html#a4b7a221e328e1dbc5ecec220f4564d7b", null ],
    [ "regAddrSize", "structNV__I2C__INFO__V3.html#a58c55623452fdad85fce6573bb83d476", null ],
    [ "version", "structNV__I2C__INFO__V3.html#ac1d04a36434b466b93caae8dac41c5b1", null ]
];