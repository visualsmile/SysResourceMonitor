var structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V1 =
[
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V1.html#a3775b9fe328a28c72959dbba22eba76e", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V1.html#a0bbd09304b294f8010324a9876e154e5", null ],
    [ "version", "structNvAPI__D3D11__CREATE__PIXEL__SHADER__EX__V1.html#a3fc0c28cd10be1d7771599c652d86507", null ]
];