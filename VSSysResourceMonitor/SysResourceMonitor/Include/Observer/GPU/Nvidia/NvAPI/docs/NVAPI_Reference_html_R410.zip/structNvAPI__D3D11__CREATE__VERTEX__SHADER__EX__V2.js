var structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V2 =
[
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V2.html#ac4a5e1b47ab55fe933d936c102b06262", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V2.html#ab16302a1adc75dd7502712dad9d45cef", null ],
    [ "UseWithFastGS", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V2.html#a9cf4dd4d103396db97815572f3df4f3e", null ],
    [ "version", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V2.html#a44886b0a408f59b4f1c3f2b932c49679", null ]
];