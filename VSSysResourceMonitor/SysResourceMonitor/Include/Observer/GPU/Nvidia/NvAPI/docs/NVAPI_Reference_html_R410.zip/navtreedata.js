var NAVTREE =
[
  [ "NVAPI Reference Documentation (Developer)", "index.html", [
    [ "NVIDIA NVAPI", "index.html", "index" ],
    [ "Legal Notice", "legal.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", "globals_type" ],
        [ "Enumerations", "globals_enum.html", "globals_enum" ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"NvApiDriverSettings_8h.html",
"NvApiDriverSettings_8h.html#a49f32517cce0158eb041adc81536cbffa08440c1d4f637b2ee3ef2e03893ff97f",
"NvApiDriverSettings_8h.html#a8e75c074b5528d10e3e021b2d595719caf0a80868deda5b855db2b4198ee2ba1c",
"NvApiDriverSettings_8h.html#abe0a4a1603e82096f3bb0f6b257c390ba32f87f94e2a7097cb69324b80e695271",
"globals_a.html",
"group__dispcontrol.html#gae160816561d8f76661c69bfde5354435",
"group__drsapi.html#ga7eba289e6cb2e0e474723e83376d0a3b",
"group__dx.html#gaabb713033af6d77be3ed032d9b53d0d8",
"group__gpu.html#ga0ab604530cc8e7ce6976201309bc304f",
"group__gpu.html#gga27ebb6be1281e11790d88cf1da64ca4fac681866508fdfa041047d51a78ef79e5",
"group__gpupstate.html#ga3d39b803ef81a211d58ba8b850210348",
"group__mosaicapi.html#ga401eca45b352036bf6e35ef4e27a4842",
"group__nvapistatus.html#gga12534f3b520256799842c0172e9afdf7a2d4426944862f2f01307dbcece3e1a2b",
"group__nvapitypes.html#ga40e070c1285684861c7915b153b54c31",
"group__stereoapi.html#gga3490c7efdf58d95d736988f324af7f1ea405ef974fbb5693f92b57e50e779e990",
"group__vidio.html#ga88dc94ea9bb4a711b3e5923fea1d1dd8",
"group__vidio.html#ggae1f8ba4a323ebe9a5f20e6b7a37ae475af9606e49e82cc71115eea288045e5527",
"nvapi_8h.html#a0fd9986cdf539cb532edcadf4cf9218d",
"nvapi_8h.html#a40f0acbe813e3d932e1a543890a61f85",
"nvapi_8h.html#a89d9f4c01e2448ba8bbebec2b2b1056ea5fa0405d626baa93434e762c0e06dbb4",
"nvapi_8h.html#ac1c3fc1103b364def5b382f9dfa3617a",
"nvapi__lite__common_8h.html#a71d8c5a15ce7af033fe27d03b1944c25",
"nvapi__lite__salstart_8h.html#a9cc41bf20cfe356f221199b57c16c56d",
"structNV__CHIPSET__INFO__v2.html#a98bd2aafac0e9f852d6fc0a619d64700",
"structNV__GPU__PSTATE20__CLOCK__ENTRY__V1.html#ade11cafe352438aa876823ff9637d204",
"structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V2.html#ade8f5c9f62c8b3d84ccb04a3387f1ae7",
"struct__NVVIOGAMMARAMP8.html",
"struct__NV__DISPLAYCONFIG__PATH__ADVANCED__TARGET__INFO__V1.html#a2c08e55a9192892d5e3898600a9cf145",
"struct__NV__GSYNC__GPU.html#af3e2ff041636bfef297528bf07e6c6df",
"struct__NV__MOSAIC__GRID__TOPO__V1.html#a672bb1647ef3e96c87e40507e486fddb",
"struct__NV__TEX2D__ARRAY__SRRV.html#a355327b74acb8c6452f1e61b28af651d"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';