var structNVAPI__D3D12__PSO__DOMAIN__SHADER__DESC__V1 =
[
    [ "NumCustomSemantics", "structNVAPI__D3D12__PSO__DOMAIN__SHADER__DESC__V1.html#a7ce4a22afeaed16c56d410cdbaab14b4", null ],
    [ "pCustomSemantics", "structNVAPI__D3D12__PSO__DOMAIN__SHADER__DESC__V1.html#a7a92bc173c4c1cef959016d224305965", null ],
    [ "version", "structNVAPI__D3D12__PSO__DOMAIN__SHADER__DESC__V1.html#ad485eaad907199f1bbca35a04b095c24", null ]
];